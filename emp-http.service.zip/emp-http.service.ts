import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IEmployee } from './IEmployee';

@Injectable({
  providedIn: 'root'
})
export class EmpHttpService {
 
  baseUrl:string = "/assets/data/emp.json"

  constructor(private http:HttpClient) { }

  getAllEmps():Observable<IEmployee[]>{
    return this.http.get<IEmployee[]>(this.baseUrl);
  }
}
      