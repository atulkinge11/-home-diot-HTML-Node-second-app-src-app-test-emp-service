import { Component, OnInit } from '@angular/core';
import { EmpHttpService } from '../emp-http.service';
import { IEmployee } from '../IEmployee';

@Component({
  selector: 'app-test-emp-service',
  templateUrl: './test-emp-service.component.html',
  styleUrls: ['./test-emp-service.component.css']
})
export class TestEmpServiceComponent implements OnInit {

  employees: IEmployee[] = [];
 
  constructor(private empHttpService:EmpHttpService) { }

  ngOnInit(): void {
    this.empHttpService.getAllEmps().subscribe(data=>this.employees=data)
  }

}
